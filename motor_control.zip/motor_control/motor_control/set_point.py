# Imports
import rclpy
from rclpy.node import Node
import numpy as np
from std_msgs.msg import Float32

# Class Definition
class SetPointPublisher(Node):
    def __init__(self):
        super().__init__('set_point_robotronicos')  # Nombre del nodo

        # Obtener parámetros de ROS2
        self.declare_parameters(
            namespace='',
            parameters=[
                ('signal_type', 'sine'),
                ('amplitude', 2.0),
                ('frequency', 1.0),
                ('step_value', 2.0),
                ('timer_period', 0.1),
                ('offset', 0.0),
            ]
        )

        self.signal_type = self.get_parameter('signal_type').get_parameter_value().string_value
        self.amplitude = self.get_parameter('amplitude').get_parameter_value().double_value
        self.frequency = self.get_parameter('frequency').get_parameter_value().double_value
        self.step_value = self.get_parameter('step_value').get_parameter_value().double_value
        self.timer_period = self.get_parameter('timer_period').get_parameter_value().double_value
        self.offset = self.get_parameter('offset').get_parameter_value().double_value

        # Crear publicador en /set_point
        self.signal_publisher = self.create_publisher(Float32, '/set_point', 10)
        self.timer = self.create_timer(self.timer_period, self.timer_cb)

        # Crear suscriptor al tópico /motor_output
        self.motor_speed_subscriber = self.create_subscription(
            Float32,
            '/motor_output',
            self.motor_output_callback,
            10
        )

        # Variable para almacenar la velocidad del motor
        self.motor_speed = 0.0

        # Inicializar variables
        self.signal_msg = Float32()
        self.start_time = self.get_clock().now().nanoseconds / 1e9  # Guardar tiempo inicial en segundos

        self.get_logger().info(f"SetPoint Node Started with {self.signal_type} signal 🚀")

    # Timer Callback: Generate and Publish Signal
    def timer_cb(self):
        current_time = self.get_clock().now().nanoseconds / 1e9  # Obtener tiempo actual en segundos
        elapsed_time = current_time - self.start_time  # Calcular tiempo transcurrido en segundos

        # Diagnosticar el tipo de señal y calcular el valor correspondiente
        if self.signal_type == "sine":
            self.signal_msg.data = self.amplitude * np.sin(2 * np.pi * self.frequency * elapsed_time) + self.offset
        elif self.signal_type == "square":
            self.signal_msg.data = self.amplitude * (1 if np.sin(2 * np.pi * self.frequency * elapsed_time) >= 0 else -1) + self.offset
        elif self.signal_type == "step":
            self.signal_msg.data = self.step_value + self.offset
        else:
            self.get_logger().warn("Invalid signal type! Using default sine wave.")
            self.signal_msg.data = self.amplitude * np.sin(2 * np.pi * self.frequency * elapsed_time) + self.offset

        # Publicar la señal
        self.signal_publisher.publish(self.signal_msg)
        self.get_logger().debug(f"Published: {self.signal_msg.data}")

    # Callback para recibir la velocidad del motor desde /motor_output
    def motor_output_callback(self, msg):
        self.motor_speed = msg.data
        self.get_logger().info(f"Received motor speed: {self.motor_speed:.2f} rad/s")

# Main
def main(args=None):
    rclpy.init(args=args)
    set_point = SetPointPublisher()

    try:
        rclpy.spin(set_point)
    except KeyboardInterrupt:
        pass
    finally:
        set_point.destroy_node()
        rclpy.shutdown()

# Execute Node
if __name__ == '__main__':
    main()