from launch import LaunchDescription
from launch_ros.actions import Node
from launch.substitutions import TextSubstitution

def generate_launch_description():
    input_node = Node(
        package='motor_control',
        executable='set_point',
        name='set_point_robotronicos',
        output='screen',
        parameters=[
            {'signal_type': 'sine'},
            {'amplitude': TextSubstitution(text='2.0')},
            {'frequency': TextSubstitution(text='1.0')},
            {'step_value': TextSubstitution(text='2.0')},
            {'timer_period': TextSubstitution(text='0.1')}
        ]
    )

    rqt_plot = Node(
        package='rqt_plot',
        executable='rqt_plot',
        output='screen'
    )

    rqt_graph = Node(
        package='rqt_graph',
        executable='rqt_graph',
        output='screen'
    )

    rqt_reconfigure = Node(
        package='rqt_reconfigure',
        executable='rqt_reconfigure',
        output='screen'
    )

    return LaunchDescription([input_node, rqt_plot, rqt_graph, rqt_reconfigure])